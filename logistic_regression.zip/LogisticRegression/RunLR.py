# The implementation for "Network-based protein structural classification" paper
# Logistic Regression framework
# Author: Mahboobeh Ghalehnovi
# Feburary 2020

from ClassifyingLR import logistic_regression


dataset = 'Cath3.30.390'
sampling_type = 0 # 0 is for proportional sampling, 1 is for SMOTE sampling
# metric can be either 'ACC' which stands for accuracy or 'MCC' which
# stands for Matthews correlation coefficient
metric = 'ACC'
save_acc_perclass = True  # True or False
logistic_regression(dataset, sampling_type, metric, save_acc_perclass)
